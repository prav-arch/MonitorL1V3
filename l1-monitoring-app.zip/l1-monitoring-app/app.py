import os
import logging
from flask import Flask, render_template, request, jsonify, Response
from flask_cors import CORS
import config
from utils.log_processor import LogProcessor
from utils.rag_engine import RAGEngine
from utils.llm_interface import LLMInterface
from utils.vector_store import VectorStore

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
CORS(app)

# Import database models and utilities
from database_models import DBLogEntry, get_db_session
from sqlalchemy import func
import db_init
import traceback

# Initialize database (this handles sample data as well)
db_init.initialize_database()

# Initialize components
vector_store = VectorStore(index_path=config.VECTOR_DB_PATH)
llm_interface = LLMInterface(model_name=config.OLLAMA_MODEL)
log_processor = LogProcessor(embedding_model_name=config.EMBEDDING_MODEL)
rag_engine = RAGEngine(vector_store=vector_store, llm_interface=llm_interface)

# Sample logs for fallback if database fails
SAMPLE_LOGS = db_init.SAMPLE_LOGS

@app.route('/')
def index():
    """Render the main application page"""
    return render_template('index.html')

@app.route('/api/logs', methods=['GET'])
def get_logs():
    """API endpoint to retrieve logs from database"""
    try:
        session = get_db_session()
        # Get logs from database with pagination
        limit = request.args.get('limit', default=100, type=int)
        offset = request.args.get('offset', default=0, type=int)
        level_filter = request.args.get('level', default=None)
        service_filter = request.args.get('service', default=None)
        
        # Build query
        query = session.query(DBLogEntry)
        
        # Apply filters if provided
        if level_filter:
            query = query.filter(DBLogEntry.level == level_filter)
        if service_filter:
            query = query.filter(DBLogEntry.service == service_filter)
            
        # Order by timestamp descending and apply pagination
        logs = query.order_by(DBLogEntry.timestamp.desc()).limit(limit).offset(offset).all()
        
        # Convert to dictionary
        result = [log.to_dict() for log in logs]
        session.close()
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error fetching logs from database: {str(e)}")
        logger.error(traceback.format_exc())
        # Fallback to sample logs if database fails
        return jsonify(SAMPLE_LOGS)

@app.route('/api/logs/upload', methods=['POST'])
def upload_logs():
    """API endpoint to upload and process log files"""
    if 'logfile' not in request.files:
        return jsonify({"error": "No file provided"}), 400
    
    file = request.files['logfile']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400
    
    # Process the log file
    try:
        log_content = file.read().decode('utf-8')
        log_entries = log_processor.parse_logs(log_content)
        
        # Process logs for vector embeddings
        log_processor.process_logs_for_embeddings(log_entries, vector_store)
        
        # Save logs to database
        session = get_db_session()
        saved_count = 0
        
        for log_entry in log_entries:
            # Create database model from log entry
            db_log = DBLogEntry(
                timestamp=log_entry.timestamp,
                level=log_entry.level,
                message=log_entry.message,
                service=log_entry.service,
                additional_fields=log_entry.additional_fields
            )
            session.add(db_log)
            saved_count += 1
            
            # Commit in batches to avoid memory issues
            if saved_count % 100 == 0:
                session.commit()
        
        # Final commit for remaining logs
        session.commit()
        session.close()
        
        logger.info(f"Saved {saved_count} logs to database")
        
        # Return result
        return jsonify({
            "message": f"Log file processed successfully. {saved_count} logs saved to database.",
            "log_count": len(log_entries),
            "logs": [log.to_dict() for log in log_entries[:100]]  # Return first 100 logs for display
        })
    except Exception as e:
        logger.error(f"Error processing log file: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({"error": f"Failed to process log file: {str(e)}"}), 500

@app.route('/api/analyze', methods=['POST'])
def analyze_logs():
    """API endpoint to analyze logs and provide suggestions"""
    data = request.json
    if not data or 'query' not in data:
        return jsonify({"error": "No query provided"}), 400
    
    query = data['query']
    selected_logs = data.get('selected_logs', [])
    
    try:
        # Retrieve relevant log context using RAG
        context_logs = rag_engine.retrieve_relevant_logs(query, top_k=5)
        
        # If specific logs were selected by the user, add them to the context
        if selected_logs:
            context_logs.extend(selected_logs)
        
        # Generate suggestion using the LLM and retrieved context
        suggestion = rag_engine.generate_suggestion(query, context_logs)
        
        return jsonify({
            "suggestion": suggestion,
            "relevant_logs": context_logs
        })
    except Exception as e:
        logger.error(f"Error analyzing logs: {str(e)}")
        return jsonify({"error": f"Failed to analyze logs: {str(e)}"}), 500

@app.route('/api/logs/stats', methods=['GET'])
def get_log_stats():
    """API endpoint to retrieve statistics about logs from database"""
    try:
        session = get_db_session()
        
        # Get total count
        total_count = session.query(DBLogEntry).count()
        
        # Get count by log level
        level_counts = {}
        level_results = session.query(DBLogEntry.level, 
                                  func.count(DBLogEntry.id))\
                          .group_by(DBLogEntry.level)\
                          .all()
        for level, count in level_results:
            level_counts[level] = count
            
        # Get count by service
        service_counts = {}
        service_results = session.query(DBLogEntry.service, 
                                    func.count(DBLogEntry.id))\
                            .group_by(DBLogEntry.service)\
                            .all()
        for service, count in service_results:
            service_name = service or "unknown"
            service_counts[service_name] = count
            
        # Get timeline data
        # For this mock version, we'll generate a simple timeline
        # In a production system, we would use SQL to group by hour
        timeline = []
        for hour in range(24):
            timestamp = f"2023-10-15T{hour:02d}:00:00"
            # Just distribute the logs across the hours for demo
            count = total_count // 24
            if hour % 3 == 0:  # Every 3rd hour has more logs for variation
                count = int(count * 1.5)
            timeline.append({"timestamp": timestamp, "count": count})
            
        session.close()
        
        # Assemble stats
        stats = {
            "total": total_count,
            "by_level": level_counts,
            "by_service": service_counts,
            "timeline": timeline
        }
        
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Error generating log stats: {str(e)}")
        logger.error(traceback.format_exc())
        
        # Fallback to sample data if database query fails
        return jsonify({
            "total": 5,  # The sample logs we added
            "by_level": {
                "ERROR": 2,
                "WARN": 1,
                "INFO": 2
            },
            "by_service": {
                "database": 4,
                "api": 1
            },
            "timeline": [
                {"timestamp": "2023-10-15T12:00:00", "count": 5}
            ]
        })

@app.route('/api/health', methods=['GET'])
def health_check():
    """API endpoint for application health check"""
    status = {
        "status": "healthy",
        "components": {
            "vector_store": vector_store.is_healthy(),
            "llm": llm_interface.is_healthy(),
            "embedding_model": log_processor.is_healthy()
        }
    }
    return jsonify(status)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
