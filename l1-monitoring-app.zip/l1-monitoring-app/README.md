# L1 Monitoring Application with RAG-based LLM

A locally-hosted GenAI application for L1 monitoring that uses RAG (Retrieval-Augmented Generation) to provide troubleshooting suggestions based on log analysis.

![L1 Monitoring Application Screenshot](generated-icon.png)

## Features

- **Log Collection**: Upload and parse log files from various sources
- **Log Storage**: Store logs in a PostgreSQL database for persistence and querying
- **Vector Search**: Implement vector similarity search to find relevant logs for troubleshooting
- **Local LLM Integration**: Use locally-hosted OLLAMA models for AI-powered suggestions
- **RAG Implementation**: Retrieve relevant logs to provide context for AI suggestions
- **Interactive UI**: View logs, charts, and AI-generated suggestions in a responsive web interface

## Architecture

The application consists of the following components:

1. **Flask Backend**: Serves the web application and APIs
2. **PostgreSQL Database**: Stores log entries and analysis results
3. **Vector Store**: Maintains embeddings for semantic search of logs
4. **LLM Interface**: Connects to a local OLLAMA model for AI-powered suggestions
5. **RAG Engine**: Combines vector search with LLM to generate contextual suggestions

## Setup

### Prerequisites

- Python 3.9+
- PostgreSQL
- OLLAMA (for local LLM functionality)

### Installation

1. **Clone the repository**:
   ```
   git clone https://github.com/yourusername/l1-monitoring-app.git
   cd l1-monitoring-app
   ```

2. **Install dependencies**:
   ```
   pip install -r requirements.txt
   ```

3. **Set up the database**:
   ```
   # Update your PostgreSQL connection string in .env or environment variables
   export DATABASE_URL=postgresql://username:password@localhost:5432/l1monitor
   ```

4. **Set up OLLAMA**:
   Follow the instructions in [OLLAMA_SETUP.md](OLLAMA_SETUP.md) to install and configure OLLAMA.

5. **Run the application**:
   ```
   gunicorn --bind 0.0.0.0:5000 main:app
   ```

6. Open the application in your browser at `http://localhost:5000`

## Usage

### Uploading Logs

1. Click on the "Upload Logs" button
2. Select a log file (text-based logs in various formats are supported)
3. The logs will be parsed, stored in the database, and indexed for vector search

### Analyzing Logs

1. Enter a question or issue description in the analysis box
2. Optionally select specific logs you want to include in the analysis
3. Click "Analyze" to generate a suggestion
4. View the suggestion and the relevant logs that were used to generate it

### Viewing Log Statistics

The dashboard displays various statistics about your logs:
- Distribution by log level (ERROR, WARN, INFO, etc.)
- Distribution by service
- Timeline of log events

## Extending the Application

### Adding Support for New Log Formats

Edit `config.py` and add new regex patterns to the `LOG_PATTERNS` dictionary.

### Customizing LLM Parameters

Adjust the parameters in `config.py` under the `LLM_PARAMS` section to tune the output of the LLM.

### Adding New Knowledge Sources

Update the `KNOWLEDGE_SOURCES` list in `config.py` to provide additional domain knowledge.

## Troubleshooting

See the [OLLAMA_SETUP.md](OLLAMA_SETUP.md) file for troubleshooting steps related to the LLM integration.

For database issues, check the PostgreSQL connection string and ensure the database is running.