import os
import logging
import pickle
import numpy as np
from typing import List, Dict, Any, Optional, Union
from pathlib import Path

try:
    import faiss
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False
    logging.warning("FAISS not available, using simple vector store implementation")

logger = logging.getLogger(__name__)

class VectorStore:
    """Vector store implementation for storing and retrieving embeddings"""
    
    def __init__(self, index_path: str, vector_dim: int = 384):
        """Initialize the vector store with an index path and vector dimension"""
        self.index_path = index_path
        self.vector_dim = vector_dim
        self.index = None
        self.metadata = []
        self.initialized = False
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(index_path), exist_ok=True)
        
        # Try to load existing index
        self._load_index()
    
    def is_initialized(self) -> bool:
        """Check if the vector store is initialized"""
        return self.initialized
    
    def is_healthy(self) -> bool:
        """Check if the vector store is healthy"""
        return self.initialized and (
            (FAISS_AVAILABLE and self.index is not None) or 
            (not FAISS_AVAILABLE and len(self.metadata) > 0)
        )
    
    def _load_index(self) -> None:
        """Load the vector index from disk"""
        index_file = f"{self.index_path}.index"
        metadata_file = f"{self.index_path}.metadata"
        
        if os.path.exists(index_file) and os.path.exists(metadata_file):
            try:
                # Load metadata
                with open(metadata_file, 'rb') as f:
                    self.metadata = pickle.load(f)
                
                # Load index
                if FAISS_AVAILABLE:
                    self.index = faiss.read_index(index_file)
                else:
                    with open(index_file, 'rb') as f:
                        self.index = pickle.load(f)
                
                self.initialized = True
                logger.info(f"Loaded vector store with {len(self.metadata)} vectors")
            except Exception as e:
                logger.error(f"Failed to load vector store: {str(e)}")
                self._initialize_new_index()
        else:
            logger.info("Vector store not found, initializing new one")
            self._initialize_new_index()
    
    def _initialize_new_index(self) -> None:
        """Initialize a new vector index"""
        if FAISS_AVAILABLE:
            # Use FAISS for efficient similarity search
            self.index = faiss.IndexFlatL2(self.vector_dim)
        else:
            # Simple numpy-based vector store
            self.index = []
        
        self.metadata = []
        self.initialized = True
        logger.info("Initialized new vector store")
    
    def add_vector(self, vector: np.ndarray, metadata: Dict[str, Any]) -> None:
        """Add a vector and its metadata to the store"""
        if not self.initialized:
            logger.warning("Vector store not initialized")
            return
        
        # Ensure vector is the right shape and type
        vector = np.array(vector).astype(np.float32).reshape(1, -1)
        
        if FAISS_AVAILABLE:
            self.index.add(vector)
        else:
            self.index.append(vector.flatten())
        
        self.metadata.append(metadata)
    
    def search(self, query_vector: np.ndarray, k: int = 5) -> List[Dict[str, Any]]:
        """Search for similar vectors in the store"""
        if not self.initialized:
            logger.warning("Vector store not initialized")
            return []
        
        if len(self.metadata) == 0:
            logger.warning("Vector store is empty")
            return []
        
        # Ensure query vector is the right shape and type
        query_vector = np.array(query_vector).astype(np.float32).reshape(1, -1)
        
        try:
            if FAISS_AVAILABLE:
                # Use FAISS for search
                distances, indices = self.index.search(query_vector, min(k, len(self.metadata)))
                
                # Return results
                results = [
                    {"score": float(1.0 / (1.0 + distances[0][i])), "metadata": self.metadata[int(indices[0][i])]}
                    for i in range(len(indices[0]))
                ]
            else:
                # Simple numpy-based search
                all_vectors = np.array(self.index)
                distances = np.linalg.norm(all_vectors - query_vector, axis=1)
                indices = np.argsort(distances)[:k]
                
                # Return results
                results = [
                    {"score": float(1.0 / (1.0 + distances[i])), "metadata": self.metadata[i]}
                    for i in indices
                ]
            
            return results
        
        except Exception as e:
            logger.error(f"Error during vector search: {str(e)}")
            return []
    
    def save(self) -> None:
        """Save the vector store to disk"""
        if not self.initialized:
            logger.warning("Vector store not initialized, cannot save")
            return
        
        try:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(self.index_path), exist_ok=True)
            
            # Save metadata
            with open(f"{self.index_path}.metadata", 'wb') as f:
                pickle.dump(self.metadata, f)
            
            # Save index
            if FAISS_AVAILABLE:
                faiss.write_index(self.index, f"{self.index_path}.index")
            else:
                with open(f"{self.index_path}.index", 'wb') as f:
                    pickle.dump(self.index, f)
            
            logger.info(f"Saved vector store with {len(self.metadata)} vectors")
        except Exception as e:
            logger.error(f"Failed to save vector store: {str(e)}")
    
    def clear(self) -> None:
        """Clear the vector store"""
        self._initialize_new_index()
        logger.info("Cleared vector store")
