import os
import logging
import json
import requests
import time
from typing import Dict, Any, List, Optional
import config

logger = logging.getLogger(__name__)

class LLMInterface:
    """Interface for interacting with a local LLM using OLLAMA"""
    
    def __init__(self, model_name: str):
        """Initialize the LLM interface with a model name
        
        Args:
            model_name: The name of the OLLAMA model to use (e.g., 'llama2', 'mistral')
        """
        self.model_name = model_name
        self.ollama_url = os.environ.get("OLLAMA_URL", "http://localhost:11434")
        self.api_endpoint = f"{self.ollama_url}/api/generate"
        self.model_loaded = self._check_model_available()
        
        if self.model_loaded:
            logger.info(f"OLLAMA LLM model initialized: {model_name}")
        else:
            logger.warning(f"OLLAMA LLM model not available: {model_name}. Using mock responses.")
    
    def is_healthy(self) -> bool:
        """Check if the LLM is loaded and operational"""
        return self.model_loaded
    
    def _check_model_available(self) -> bool:
        """Check if the OLLAMA model is available"""
        try:
            # Try to connect to OLLAMA server
            health_url = f"{self.ollama_url}/api/health"
            response = requests.get(health_url, timeout=2)
            
            if response.status_code == 200:
                # Check if the specific model is available
                model_url = f"{self.ollama_url}/api/tags"
                model_response = requests.get(model_url, timeout=2)
                
                if model_response.status_code == 200:
                    models = model_response.json().get('models', [])
                    available_models = [model.get('name') for model in models]
                    
                    if self.model_name in available_models:
                        logger.info(f"Model '{self.model_name}' is available in OLLAMA")
                        return True
                    else:
                        logger.warning(f"Model '{self.model_name}' not found in OLLAMA. Available models: {available_models}")
            
            return False
        except requests.RequestException as e:
            logger.error(f"Error connecting to OLLAMA server: {str(e)}")
            return False
    
    def generate_text(self, prompt: str, params: Optional[Dict[str, Any]] = None) -> str:
        """Generate text using the OLLAMA LLM
        
        Args:
            prompt: The text prompt to send to the model
            params: Generation parameters (temperature, max_tokens, etc.)
            
        Returns:
            The generated text response
        """
        # Check if OLLAMA is available
        if not self.model_loaded:
            logger.warning("OLLAMA model not available, using mock response")
            return self._generate_mock_response(prompt)
        
        # Merge default params with provided params
        gen_params = config.LLM_PARAMS.copy()
        if params:
            gen_params.update(params)
        
        # Prepare the request to OLLAMA
        request_data = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": gen_params.get("temperature", 0.7),
                "top_p": gen_params.get("top_p", 0.95),
                "max_tokens": gen_params.get("max_tokens", 256)
            }
        }
        
        try:
            # Make the request to OLLAMA
            logger.info(f"Sending prompt to OLLAMA model '{self.model_name}'")
            response = requests.post(self.api_endpoint, json=request_data, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "")
            else:
                logger.error(f"Error from OLLAMA API: {response.status_code} - {response.text}")
                return f"Error generating response: {response.status_code}"
        
        except requests.RequestException as e:
            logger.error(f"Error communicating with OLLAMA: {str(e)}")
            return f"Error: {str(e)}"
    
    def _generate_mock_response(self, prompt: str) -> str:
        """Generate a mock response when OLLAMA is not available
        
        Args:
            prompt: The prompt text
            
        Returns:
            A mock response based on the prompt content
        """
        logger.info(f"Generating mock response for prompt: {prompt[:50]}...")
        
        # Create a relevant response based on the prompt content
        if "database" in prompt.lower():
            return "Check database connection settings and ensure the database service is running. Verify network connectivity and credentials."
        elif "timeout" in prompt.lower():
            return "Increase timeout settings and implement retry logic. Monitor network latency and server resources."
        elif "error" in prompt.lower():
            return "Review error logs for root cause. Check application configuration and dependencies."
        else:
            return "Based on the logs provided, there may be a system configuration issue. Check service availability and resource allocation."
    
    def generate_troubleshooting_suggestion(self, query: str, log_context: List[Dict[str, Any]]) -> str:
        """Generate a troubleshooting suggestion based on a query and log context
        
        Args:
            query: The user's query or issue description
            log_context: A list of relevant log entries
            
        Returns:
            A troubleshooting suggestion based on the query and logs
        """
        # Format the log context as a string
        log_context_str = "\n".join([
            f"[{log.get('timestamp', '')}] {log.get('level', 'INFO')} - {log.get('service', 'unknown')}: {log.get('message', '')}"
            for log in log_context
        ])
        
        # Build a prompt for the LLM
        prompt = f"""You are an AI system monitoring assistant that helps IT professionals troubleshoot issues based on log analysis.
Based on the logs and issue description below, provide a concise, actionable troubleshooting suggestion.

ISSUE DESCRIPTION:
{query}

RELEVANT LOGS:
{log_context_str}

TROUBLESHOOTING SUGGESTION:
"""
        
        # Generate the suggestion
        suggestion = self.generate_text(prompt, {"temperature": 0.3, "max_tokens": 350})
        
        # Clean up any prefix text from model output
        if "TROUBLESHOOTING SUGGESTION:" in suggestion:
            suggestion = suggestion.split("TROUBLESHOOTING SUGGESTION:", 1)[1].strip()
        
        return suggestion
