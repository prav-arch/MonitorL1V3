// Main application JavaScript

// Global variables
let allLogs = [];
let selectedLogs = [];
let logCharts = {};
let currentFilter = 'all';
let isLoading = false;

// Document ready
document.addEventListener('DOMContentLoaded', () => {
    // Initialize application
    initApp();
    
    // Event listeners
    setupEventListeners();
});

/**
 * Initialize the application
 */
function initApp() {
    // Fetch initial logs
    fetchLogs();
    
    // Fetch system status
    fetchSystemStatus();
    
    // Initialize charts
    initCharts();
    
    console.log('L1 Monitoring Application initialized');
}

/**
 * Setup event listeners for UI interactions
 */
function setupEventListeners() {
    // Refresh logs button
    document.getElementById('refresh-logs').addEventListener('click', (e) => {
        e.preventDefault();
        fetchLogs();
    });
    
    // Log filtering buttons
    document.getElementById('filter-all').addEventListener('click', () => filterLogs('all'));
    document.getElementById('filter-error').addEventListener('click', () => filterLogs('ERROR'));
    document.getElementById('filter-warn').addEventListener('click', () => filterLogs('WARN'));
    document.getElementById('filter-info').addEventListener('click', () => filterLogs('INFO'));
    
    // Log search
    document.getElementById('search-button').addEventListener('click', searchLogs);
    document.getElementById('log-search').addEventListener('keyup', (e) => {
        if (e.key === 'Enter') {
            searchLogs();
        }
    });
    
    // Analyze button
    document.getElementById('analyze-button').addEventListener('click', analyzeLogs);
    
    // Upload logs
    document.getElementById('upload-button').addEventListener('click', uploadLogFile);
    
    // Time filter for charts
    document.querySelectorAll('.time-filter').forEach(button => {
        button.addEventListener('click', (e) => {
            // Remove active class from all buttons
            document.querySelectorAll('.time-filter').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Add active class to clicked button
            e.target.classList.add('active');
            
            // Update chart time range
            updateChartTimeRange(e.target.dataset.time);
        });
    });
    
    // Toggle dark/light mode
    document.getElementById('toggle-dark-mode').addEventListener('click', (e) => {
        e.preventDefault();
        toggleDarkMode();
    });
}

/**
 * Fetch logs from the server
 */
function fetchLogs() {
    isLoading = true;
    const logsContainer = document.getElementById('logs-container');
    
    // Show loading indicator
    logsContainer.innerHTML = `
        <tr>
            <td colspan="4" class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading logs...</p>
            </td>
        </tr>
    `;
    
    // Fetch logs
    axios.get('/api/logs')
        .then(response => {
            allLogs = response.data;
            renderLogs(allLogs);
            updateLogCount(allLogs.length);
            fetchLogStats();
        })
        .catch(error => {
            console.error('Error fetching logs:', error);
            logsContainer.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center py-5 text-danger">
                        <i class="fas fa-exclamation-circle fa-2x mb-2"></i>
                        <p>Failed to load logs. Please try again.</p>
                        <p class="small text-muted">${error.message}</p>
                    </td>
                </tr>
            `;
        })
        .finally(() => {
            isLoading = false;
        });
}

/**
 * Render logs in the logs container
 * @param {Array} logs - Array of log objects to render
 */
function renderLogs(logs) {
    if (isLoading) return;
    
    const logsContainer = document.getElementById('logs-container');
    
    if (logs.length === 0) {
        logsContainer.innerHTML = `
            <tr>
                <td colspan="4" class="text-center py-5">
                    <i class="fas fa-search fa-2x mb-2 text-muted"></i>
                    <p>No logs found matching your criteria.</p>
                </td>
            </tr>
        `;
        return;
    }
    
    // Clear container
    logsContainer.innerHTML = '';
    
    // Render each log
    logs.forEach((log, index) => {
        const isSelected = selectedLogs.some(selectedLog => 
            selectedLog.timestamp === log.timestamp && 
            selectedLog.message === log.message
        );
        
        const row = document.createElement('tr');
        row.className = `log-entry ${isSelected ? 'selected' : ''}`;
        row.dataset.index = index;
        
        // Format timestamp to be more readable
        let timestamp = log.timestamp;
        try {
            const date = new Date(log.timestamp);
            timestamp = date.toLocaleString();
        } catch (e) {
            // Keep original timestamp if parsing fails
        }
        
        row.innerHTML = `
            <td>${timestamp}</td>
            <td><span class="badge level-badge level-${log.level}">${log.level}</span></td>
            <td>${log.service || 'unknown'}</td>
            <td>${escapeHtml(log.message)}</td>
        `;
        
        // Add click event to select/deselect log
        row.addEventListener('click', () => {
            toggleLogSelection(row, log);
        });
        
        logsContainer.appendChild(row);
    });
}

/**
 * Toggle log selection for analysis
 * @param {Element} row - The row element that was clicked
 * @param {Object} log - The log object associated with the row
 */
function toggleLogSelection(row, log) {
    row.classList.toggle('selected');
    
    if (row.classList.contains('selected')) {
        // Add to selected logs
        selectedLogs.push(log);
    } else {
        // Remove from selected logs
        selectedLogs = selectedLogs.filter(selectedLog => 
            !(selectedLog.timestamp === log.timestamp && 
              selectedLog.message === log.message)
        );
    }
    
    // Update count in UI if needed
    updateSelectedLogCount();
}

/**
 * Update the selected log count in UI
 */
function updateSelectedLogCount() {
    const count = selectedLogs.length;
    const analyzeButton = document.getElementById('analyze-button');
    
    if (count > 0) {
        analyzeButton.innerHTML = `<i class="fas fa-search me-2"></i> Analyze ${count} Selected Logs`;
    } else {
        analyzeButton.innerHTML = `<i class="fas fa-search me-2"></i> Analyze Logs`;
    }
}

/**
 * Update the log count display
 * @param {number} count - The number of logs
 */
function updateLogCount(count) {
    const logCount = document.getElementById('log-count');
    logCount.textContent = count;
}

/**
 * Filter logs by level
 * @param {string} level - The log level to filter by ('all' for no filtering)
 */
function filterLogs(level) {
    currentFilter = level;
    
    let filteredLogs;
    if (level === 'all') {
        filteredLogs = allLogs;
    } else {
        filteredLogs = allLogs.filter(log => log.level === level);
    }
    
    renderLogs(filteredLogs);
    updateLogCount(filteredLogs.length);
}

/**
 * Search logs by text
 */
function searchLogs() {
    const searchInput = document.getElementById('log-search');
    const searchText = searchInput.value.trim().toLowerCase();
    
    if (searchText === '') {
        filterLogs(currentFilter); // Reset to current filter
        return;
    }
    
    let searchResults;
    if (currentFilter === 'all') {
        searchResults = allLogs.filter(log => 
            log.message.toLowerCase().includes(searchText) || 
            (log.service && log.service.toLowerCase().includes(searchText))
        );
    } else {
        searchResults = allLogs.filter(log => 
            log.level === currentFilter && 
            (log.message.toLowerCase().includes(searchText) || 
             (log.service && log.service.toLowerCase().includes(searchText)))
        );
    }
    
    renderLogs(searchResults);
    updateLogCount(searchResults.length);
}

/**
 * Analyze logs using the RAG engine
 */
function analyzeLogs() {
    const issueDescription = document.getElementById('issue-description').value.trim();
    
    if (issueDescription === '') {
        alert('Please describe the issue or ask a question.');
        return;
    }
    
    // Show loading indicator
    document.getElementById('suggestion-loading').style.display = 'flex';
    document.getElementById('suggestion-container').style.display = 'none';
    
    const payload = {
        query: issueDescription,
        selected_logs: selectedLogs.length > 0 ? selectedLogs : undefined
    };
    
    axios.post('/api/analyze', payload)
        .then(response => {
            // Hide loading indicator
            document.getElementById('suggestion-loading').style.display = 'none';
            document.getElementById('suggestion-container').style.display = 'block';
            
            // Update suggestion content
            renderSuggestion(response.data.suggestion);
            
            // Update relevant logs
            renderRelevantLogs(response.data.relevant_logs);
        })
        .catch(error => {
            console.error('Error analyzing logs:', error);
            document.getElementById('suggestion-loading').style.display = 'none';
            document.getElementById('suggestion-container').style.display = 'block';
            document.getElementById('suggestion-content').innerHTML = `
                <div class="text-danger">
                    <i class="fas fa-exclamation-circle me-1"></i>
                    Failed to analyze logs: ${error.response?.data?.error || error.message}
                </div>
            `;
            document.getElementById('relevant-logs').innerHTML = '';
        });
}

/**
 * Render the suggestion from the AI
 * @param {string} suggestion - The suggestion text
 */
function renderSuggestion(suggestion) {
    const suggestionContent = document.getElementById('suggestion-content');
    
    // Highlight key parts of the suggestion
    suggestion = suggestion.replace(/error/gi, '<span class="suggestion-highlight">error</span>');
    suggestion = suggestion.replace(/warning/gi, '<span class="suggestion-highlight">warning</span>');
    suggestion = suggestion.replace(/failed/gi, '<span class="suggestion-highlight">failed</span>');
    suggestion = suggestion.replace(/timeout/gi, '<span class="suggestion-highlight">timeout</span>');
    
    // Replace newlines with <br> tags
    suggestion = suggestion.replace(/\n/g, '<br>');
    
    suggestionContent.innerHTML = suggestion;
}

/**
 * Render the relevant logs identified by the RAG system
 * @param {Array} logs - Array of relevant log objects
 */
function renderRelevantLogs(logs) {
    const relevantLogsContainer = document.getElementById('relevant-logs');
    
    if (!logs || logs.length === 0) {
        relevantLogsContainer.innerHTML = `
            <div class="list-group-item text-center text-muted">
                No relevant logs found
            </div>
        `;
        return;
    }
    
    relevantLogsContainer.innerHTML = '';
    
    logs.forEach(log => {
        const logItem = document.createElement('a');
        logItem.href = '#';
        logItem.className = 'list-group-item list-group-item-action';
        
        // Format timestamp to be more readable
        let timestamp = log.timestamp;
        try {
            const date = new Date(log.timestamp);
            timestamp = date.toLocaleString();
        } catch (e) {
            // Keep original timestamp if parsing fails
        }
        
        logItem.innerHTML = `
            <div class="d-flex w-100 justify-content-between">
                <span class="badge level-badge level-${log.level}">${log.level}</span>
                <small>${timestamp}</small>
            </div>
            <p class="mb-1">${escapeHtml(log.message)}</p>
            <small>${log.service || 'unknown'}</small>
        `;
        
        // Click to highlight the log in the main list
        logItem.addEventListener('click', (e) => {
            e.preventDefault();
            highlightLogInMainList(log);
        });
        
        relevantLogsContainer.appendChild(logItem);
    });
}

/**
 * Highlight a log entry in the main log list
 * @param {Object} log - The log object to highlight
 */
function highlightLogInMainList(log) {
    // Find the log in allLogs
    const logIndex = allLogs.findIndex(l => 
        l.timestamp === log.timestamp && l.message === log.message
    );
    
    if (logIndex === -1) {
        // Log not found in current view
        return;
    }
    
    // Reset filter to show all logs
    filterLogs('all');
    
    // Find the row
    const row = document.querySelector(`.log-entry[data-index="${logIndex}"]`);
    if (row) {
        // Scroll to the row
        row.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Highlight the row briefly
        row.classList.add('bg-primary', 'text-white');
        setTimeout(() => {
            row.classList.remove('bg-primary', 'text-white');
        }, 1500);
    }
}

/**
 * Fetch log statistics for charts
 */
function fetchLogStats() {
    axios.get('/api/logs/stats')
        .then(response => {
            updateCharts(response.data);
        })
        .catch(error => {
            console.error('Error fetching log stats:', error);
        });
}

/**
 * Initialize charts
 */
function initCharts() {
    const logTimelineCtx = document.getElementById('logTimeline').getContext('2d');
    const severityChartCtx = document.getElementById('severityChart').getContext('2d');
    const serviceChartCtx = document.getElementById('serviceChart').getContext('2d');
    
    // Log timeline chart (line chart)
    logCharts.timeline = new Chart(logTimelineCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Log Count',
                data: [],
                borderColor: '#0d6efd',
                backgroundColor: 'rgba(13, 110, 253, 0.1)',
                tension: 0.1,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)'
                    }
                }
            }
        }
    });
    
    // Severity chart (pie chart)
    logCharts.severity = new Chart(severityChartCtx, {
        type: 'doughnut',
        data: {
            labels: ['ERROR', 'WARN', 'INFO'],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: [
                    '#dc3545', // Error (red)
                    '#ffc107', // Warning (yellow)
                    '#0dcaf0'  // Info (blue)
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
    
    // Service chart (bar chart)
    logCharts.service = new Chart(serviceChartCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Log Count',
                data: [],
                backgroundColor: 'rgba(13, 110, 253, 0.7)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)'
                    }
                }
            }
        }
    });
}

/**
 * Update charts with log statistics
 * @param {Object} stats - Log statistics object
 */
function updateCharts(stats) {
    // Update timeline chart
    const timelineLabels = stats.timeline.map(item => {
        const date = new Date(item.timestamp);
        return date.toLocaleTimeString();
    });
    const timelineData = stats.timeline.map(item => item.count);
    
    logCharts.timeline.data.labels = timelineLabels;
    logCharts.timeline.data.datasets[0].data = timelineData;
    logCharts.timeline.update();
    
    // Update severity chart
    logCharts.severity.data.datasets[0].data = [
        stats.by_level.ERROR || 0,
        stats.by_level.WARN || 0,
        stats.by_level.INFO || 0
    ];
    logCharts.severity.update();
    
    // Update service chart
    const serviceLabels = Object.keys(stats.by_service);
    const serviceData = Object.values(stats.by_service);
    
    logCharts.service.data.labels = serviceLabels;
    logCharts.service.data.datasets[0].data = serviceData;
    logCharts.service.update();
}

/**
 * Update chart time range
 * @param {string} timeRange - Time range identifier ('hour', 'day', 'week')
 */
function updateChartTimeRange(timeRange) {
    // This would normally fetch new data from the server with different time ranges
    // For this demo, we'll just modify the existing data
    
    let timelineLabels = [];
    let timelineData = [];
    
    switch (timeRange) {
        case 'hour':
            // Last hour data (simulated)
            for (let i = 0; i < 12; i++) {
                const date = new Date();
                date.setMinutes(date.getMinutes() - (i * 5));
                timelineLabels.unshift(date.toLocaleTimeString());
                timelineData.unshift(Math.floor(Math.random() * 30));
            }
            break;
        case 'day':
            // Last day data (simulated)
            for (let i = 0; i < 24; i++) {
                const date = new Date();
                date.setHours(date.getHours() - i);
                timelineLabels.unshift(date.toLocaleTimeString());
                timelineData.unshift(Math.floor(Math.random() * 100));
            }
            break;
        case 'week':
            // Last week data (simulated)
            for (let i = 0; i < 7; i++) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                timelineLabels.unshift(date.toLocaleDateString());
                timelineData.unshift(Math.floor(Math.random() * 500));
            }
            break;
    }
    
    logCharts.timeline.data.labels = timelineLabels;
    logCharts.timeline.data.datasets[0].data = timelineData;
    logCharts.timeline.update();
}

/**
 * Upload a log file for processing
 */
function uploadLogFile() {
    const fileInput = document.getElementById('logfile');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Please select a file to upload.');
        return;
    }
    
    // Show progress
    const progressBar = document.getElementById('upload-progress');
    const progressContainer = document.querySelector('.upload-progress-container');
    const statusText = document.getElementById('upload-status');
    
    progressContainer.classList.remove('d-none');
    progressBar.style.width = '0%';
    statusText.textContent = 'Uploading...';
    
    // Create form data
    const formData = new FormData();
    formData.append('logfile', file);
    
    // Upload file
    axios.post('/api/logs/upload', formData, {
        headers: {
            'Content-Type': 'multipart/form-data'
        },
        onUploadProgress: progressEvent => {
            const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            progressBar.style.width = `${percentCompleted}%`;
            progressBar.setAttribute('aria-valuenow', percentCompleted);
        }
    })
    .then(response => {
        statusText.textContent = 'Upload successful!';
        progressBar.classList.remove('bg-primary');
        progressBar.classList.add('bg-success');
        
        // Update logs with the newly processed logs
        allLogs = response.data.logs;
        renderLogs(allLogs);
        updateLogCount(allLogs.length);
        fetchLogStats();
        
        // Close modal after a delay
        setTimeout(() => {
            const uploadModal = bootstrap.Modal.getInstance(document.getElementById('uploadModal'));
            uploadModal.hide();
            
            // Reset progress bar
            progressContainer.classList.add('d-none');
            progressBar.style.width = '0%';
            progressBar.classList.remove('bg-success');
            progressBar.classList.add('bg-primary');
            fileInput.value = '';
        }, 1500);
    })
    .catch(error => {
        console.error('Error uploading file:', error);
        statusText.textContent = `Upload failed: ${error.response?.data?.error || error.message}`;
        progressBar.classList.remove('bg-primary');
        progressBar.classList.add('bg-danger');
    });
}

/**
 * Fetch system health status
 */
function fetchSystemStatus() {
    axios.get('/api/health')
        .then(response => {
            updateSystemStatus(response.data);
        })
        .catch(error => {
            console.error('Error fetching system status:', error);
            document.getElementById('system-status').innerHTML = `
                <i class="fas fa-circle text-danger"></i> Offline
            `;
            document.getElementById('system-status').classList.remove('online');
            document.getElementById('system-status').classList.add('offline');
        });
}

/**
 * Update system status in the UI
 * @param {Object} status - System status object
 */
function updateSystemStatus(status) {
    const systemStatusElem = document.getElementById('system-status');
    const llmStatusElem = document.getElementById('llm-status');
    const vectorStatusElem = document.getElementById('vector-status');
    const embeddingStatusElem = document.getElementById('embedding-status');
    
    // Overall system status
    if (status.status === 'healthy') {
        systemStatusElem.innerHTML = `<i class="fas fa-circle"></i> Online`;
        systemStatusElem.classList.add('online');
        systemStatusElem.classList.remove('offline');
    } else {
        systemStatusElem.innerHTML = `<i class="fas fa-circle"></i> Degraded`;
        systemStatusElem.classList.remove('online');
        systemStatusElem.classList.add('offline');
    }
    
    // LLM status
    if (status.components.llm) {
        llmStatusElem.textContent = 'Operational';
        llmStatusElem.className = 'badge bg-success';
    } else {
        llmStatusElem.textContent = 'Unavailable';
        llmStatusElem.className = 'badge bg-danger';
    }
    
    // Vector store status
    if (status.components.vector_store) {
        vectorStatusElem.textContent = 'Operational';
        vectorStatusElem.className = 'badge bg-success';
    } else {
        vectorStatusElem.textContent = 'Unavailable';
        vectorStatusElem.className = 'badge bg-danger';
    }
    
    // Embedding model status
    if (status.components.embedding_model) {
        embeddingStatusElem.textContent = 'Operational';
        embeddingStatusElem.className = 'badge bg-success';
    } else {
        embeddingStatusElem.textContent = 'Unavailable';
        embeddingStatusElem.className = 'badge bg-danger';
    }
}

/**
 * Toggle between dark and light mode
 */
function toggleDarkMode() {
    const htmlElement = document.documentElement;
    const currentTheme = htmlElement.getAttribute('data-bs-theme');
    
    if (currentTheme === 'dark') {
        htmlElement.setAttribute('data-bs-theme', 'light');
    } else {
        htmlElement.setAttribute('data-bs-theme', 'dark');
    }
}

/**
 * Escape HTML special characters
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    
    return text.replace(/[&<>"']/g, m => map[m]);
}
