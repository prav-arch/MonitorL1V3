from sqlalchemy import Column, Integer, String, DateTime, Text, JSON, ForeignKey, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from datetime import datetime
import os
import json

# Create the SQLAlchemy base
Base = declarative_base()

class DBLogEntry(Base):
    """Database model for log entries"""
    __tablename__ = 'log_entries'
    
    id = Column(Integer, primary_key=True)
    timestamp = Column(String(30), nullable=False, index=True)
    level = Column(String(10), nullable=False, index=True)
    message = Column(Text, nullable=False)
    service = Column(String(50), nullable=True, index=True)
    additional_fields = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert to dictionary representation"""
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "level": self.level,
            "message": self.message,
            "service": self.service or "unknown",
            **(self.additional_fields or {})
        }
    
    @classmethod
    def from_log_entry(cls, log_entry):
        """Create from LogEntry dataclass"""
        return cls(
            timestamp=log_entry.timestamp,
            level=log_entry.level,
            message=log_entry.message,
            service=log_entry.service,
            additional_fields=log_entry.additional_fields
        )

class DBAnalysisQuery(Base):
    """Database model for analysis queries"""
    __tablename__ = 'analysis_queries'
    
    id = Column(Integer, primary_key=True)
    query_text = Column(Text, nullable=False)
    suggestion = Column(Text, nullable=False)
    confidence_score = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationship with relevant logs through association table
    relevant_logs = relationship(
        'DBLogEntry', 
        secondary='analysis_log_associations',
        backref='analysis_queries'
    )

# Association table for many-to-many relationship
class AnalysisLogAssociation(Base):
    """Association table for analysis queries and relevant logs"""
    __tablename__ = 'analysis_log_associations'
    
    analysis_id = Column(Integer, ForeignKey('analysis_queries.id'), primary_key=True)
    log_id = Column(Integer, ForeignKey('log_entries.id'), primary_key=True)

# Setup database connection
def get_db_session():
    """Get a database session"""
    db_url = os.environ.get('DATABASE_URL')
    engine = create_engine(db_url)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    return Session()

# Initialize database
def init_db():
    """Initialize the database"""
    db_url = os.environ.get('DATABASE_URL')
    engine = create_engine(db_url)
    Base.metadata.create_all(engine)
    print("Database tables created.")