import os
from pathlib import Path

# Base directory
BASE_DIR = Path(__file__).resolve().parent

# OLLAMA LLM model name (use 'llama2' as default)
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama2")
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")
# Kept for backward compatibility
LLM_MODEL_PATH = OLLAMA_MODEL

# Vector database path
VECTOR_DB_PATH = os.environ.get("VECTOR_DB_PATH", str(BASE_DIR / "data" / "vector_index"))

# Embedding model name (using a lightweight model that can run locally)
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "all-MiniLM-L6-v2")

# Maximum number of log entries to process at once
MAX_LOG_ENTRIES = int(os.environ.get("MAX_LOG_ENTRIES", 1000))

# Number of top logs to retrieve for RAG
TOP_K_LOGS = int(os.environ.get("TOP_K_LOGS", 5))

# LLM generation parameters
LLM_PARAMS = {
    "max_tokens": int(os.environ.get("LLM_MAX_TOKENS", 256)),
    "temperature": float(os.environ.get("LLM_TEMPERATURE", 0.7)),
    "top_p": float(os.environ.get("LLM_TOP_P", 0.95)),
}

# Log parsing regex patterns
LOG_PATTERNS = {
    "default": r"(?P<timestamp>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z)\s+(?P<level>\w+)\s+(?P<message>.*)",
    "apache": r'(?P<ip>\S+) \S+ \S+ \[(?P<timestamp>[^]]+)\] "(?P<method>\S+) (?P<path>\S+) \S+" (?P<status>\d+) (?P<size>\S+)',
    "nginx": r'(?P<ip>\S+) - \S+ \[(?P<timestamp>[^]]+)\] "(?P<method>\S+) (?P<path>\S+) \S+" (?P<status>\d+) (?P<size>\d+)',
}

# Troubleshooting knowledge sources
KNOWLEDGE_SOURCES = [
    "Common database connection issues often involve network problems, credential errors, or resource limitations.",
    "API timeouts frequently occur due to overloaded servers, network latency, or misconfigured timeout settings.",
    "Web server 500 errors typically indicate server-side application failures or resource constraints.",
    "Authentication failures may be caused by expired credentials, permission issues, or identity service outages.",
    "High CPU usage can result from inefficient queries, background processes, or resource contention.",
    "Memory leaks gradually consume available RAM, often due to objects not being properly garbage collected.",
    "Disk I/O bottlenecks may cause system-wide slowdowns and are typically resolved by optimizing data access patterns.",
    "Network connectivity issues might be related to DNS resolution, firewall rules, or physical infrastructure problems.",
]
