"""
Database initialization script for L1 Monitoring application
"""
import os
import logging
from database_models import init_db, get_db_session, DBLogEntry

logger = logging.getLogger(__name__)

# Sample logs for initial database population
SAMPLE_LOGS = [
    {"timestamp": "2023-10-15T12:34:56", "level": "ERROR", "message": "Connection refused to database server", "service": "database"},
    {"timestamp": "2023-10-15T12:35:01", "level": "ERROR", "message": "Timeout exceeded while waiting for connection", "service": "api"},
    {"timestamp": "2023-10-15T12:35:10", "level": "WARN", "message": "Retry attempt 1 after connection failure", "service": "database"},
    {"timestamp": "2023-10-15T12:36:00", "level": "INFO", "message": "Service restarting", "service": "database"},
    {"timestamp": "2023-10-15T12:37:30", "level": "INFO", "message": "Connection established successfully", "service": "database"}
]

def initialize_database():
    """Initialize the database with sample logs if needed"""
    try:
        # Initialize database schema
        init_db()
        logger.info("Database initialized successfully")
        
        # Add sample logs
        try:
            session = get_db_session()
            
            # Check if database is empty
            if session.query(DBLogEntry).count() == 0:
                # Add sample logs directly to database without using LogEntry class
                for log_data in SAMPLE_LOGS:
                    # Create the database model directly
                    db_log = DBLogEntry(
                        timestamp=log_data.get("timestamp", ""),
                        level=log_data.get("level", "INFO"),
                        message=log_data.get("message", ""),
                        service=log_data.get("service"),
                        additional_fields={k: v for k, v in log_data.items() 
                                          if k not in ["timestamp", "level", "message", "service"]}
                    )
                    session.add(db_log)
                
                session.commit()
                logger.info("Added sample logs to database")
            
            session.close()
        except Exception as e:
            logger.error(f"Failed to add sample logs to database: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
    
    except Exception as e:
        logger.error(f"Failed to initialize database: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    
    # Initialize database
    initialize_database()